const Error = () => {
  return (
    <div className="error bckLog">
      <h1 className="errorh">404 Page Error Found</h1>
    </div>
  );
};
export default Error;
